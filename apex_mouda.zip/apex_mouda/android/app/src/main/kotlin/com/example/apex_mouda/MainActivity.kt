package com.example.apex_mouda

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
