class MyRoutes {
  static String loginRoute = "/login";
  static String splaseRoute = "/splase";
  static String seleteRoute = "/selete";
  static String seleteHome = "/home";
  static String seleteenquiry = "/enquiry";
  static String addenquiry = "/add_enquiry";
  static String selectUseful = "/useful";
  static String selectUsefuldetails = "/usefuldetails";
  static String viewholiday = "/holiday";
  static String newsevent = "/event";
  static String alphasearch = "/alphasearch";
  static String alphasearchData = "/alphasearchdata";
  static String alphasearchDataDetails = "/alphasearchDataDetails";
  static String members = "/member";
  static String committee = "/committees";
  static String adsImage = "/adsImage";
  static String selectLoginOrGuest = "/selectEntryType";
  static String profile = "/profile";

}