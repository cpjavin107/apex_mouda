class FontSize{
  static double h1 = 20;
  static double h2 = 18;
  static double h3 = 16;
  static double h4 = 14;
  static double body1 = 12;
  static double body2 = 10;
}