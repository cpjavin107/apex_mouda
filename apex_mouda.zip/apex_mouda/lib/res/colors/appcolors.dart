

import 'dart:ui';
// ignore_for_file: prefer_const_constructors

class AppColors{
  static const Color  Main_Color = Color(0xfff8ebeb);
  static const Color  Gray_Color = Color(0xfff8ebeb);
  static const Color  Button_Color = Color(0xfff47a14);
  static const Color  t_Color = Color(0xffffc7c7);
  static const Color  t_Color2 = Color(0xfffff9f5);
  static const Color  t_Color3 = Color(0xffcdf3c6);
  static const Color  t_Color4 = Color(0xffdaecff);
  static const Color  t_Color5 = Color(0xff008a00);
  static const maroonColor = Color(0xff800000);
}