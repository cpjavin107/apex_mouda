
class SpConstants{

  static String MEMBER_ID = "member_id";
  static String NAME = "name";
  static String EMAIL = "email";
  static String MOBILE_NUMBER = "mobileNumber";
  static String FIRM = "firm";
  static String IMAGE = "image";
  static String TYPE_NAME = "type_name";
  static String USER_LOGIN = "user_login";

}